﻿namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_GerencialReport_Terceros {
        partial class DS_GerencialReport_TercerosDataTable
        {
        }
    }
}
