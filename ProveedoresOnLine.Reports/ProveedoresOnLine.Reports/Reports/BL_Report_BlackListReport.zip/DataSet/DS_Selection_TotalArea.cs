﻿namespace ProveedoresOnLine.Reports.Reports.DataSet
{


    partial class DS_Selection_TotalArea
    {
        partial class DS_Selection_TotalAreaDataTable
        {
        }
    }
}
