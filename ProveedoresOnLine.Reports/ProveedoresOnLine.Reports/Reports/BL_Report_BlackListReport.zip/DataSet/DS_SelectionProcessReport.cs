﻿namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_SelectionProcessReport {
        partial class areasDataTable
        {
        }
    }
}
