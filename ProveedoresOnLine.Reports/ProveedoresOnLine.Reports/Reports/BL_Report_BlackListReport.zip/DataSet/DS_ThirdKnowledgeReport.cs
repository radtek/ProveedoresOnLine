﻿namespace ProveedoresOnLine.Reports.Reports.DataSet
{
}
namespace ProveedoresOnLine.Reports.Reports.DataSet
{
}
namespace ProveedoresOnLine.Reports.Reports.DataSet
{
}
namespace ProveedoresOnLine.Reports.Reports.DataSet
{
}
namespace ProveedoresOnLine.Reports.Reports.DataSet
{
}
namespace ProveedoresOnLine.Reports.Reports.DataSet
{


    public partial class DS_ThirdKnowledgeReport
    {
    }
}
