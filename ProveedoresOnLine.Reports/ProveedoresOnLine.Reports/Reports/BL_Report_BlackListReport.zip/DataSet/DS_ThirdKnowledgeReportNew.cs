﻿namespace ProveedoresOnLine.Reports.Reports.DataSet
{


    public partial class DS_ThirdKnowledgeReportNew
    {
    }
}
namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_ThirdKnowledgeReportNew {
    }
}
