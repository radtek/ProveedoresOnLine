﻿namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_CalificationReport_Certification {
    }
}
namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_CalificationReport_Certification {
    }
}
