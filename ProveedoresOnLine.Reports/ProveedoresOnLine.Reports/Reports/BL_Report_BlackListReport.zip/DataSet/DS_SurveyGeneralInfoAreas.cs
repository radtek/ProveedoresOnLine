﻿namespace ProveedoresOnLine.Reports.Reports.DataSet
{


    partial class DS_SurveyGeneralInfoAreas
    {
        partial class DS_SurveyGeneralInfoAreasDataTable
        {
        }
    }
}
