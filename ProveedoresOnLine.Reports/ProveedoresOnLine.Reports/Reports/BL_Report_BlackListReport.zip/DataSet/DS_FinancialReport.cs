﻿namespace ProveedoresOnLine.Reports.Reports.DataSet
{


    partial class DS_FinancialReport
    {
        partial class BalanceInfoDataTable
        {
        }
    }
}
