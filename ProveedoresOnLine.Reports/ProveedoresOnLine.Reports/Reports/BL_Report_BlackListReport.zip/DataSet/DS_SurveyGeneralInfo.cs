﻿namespace ProveedoresOnLine.Reports.Reports.DataSet
{


    public partial class DS_SurveyGeneralInfo
    {
        partial class DS_SurveyGeneralInfoDataTable
        {
        }
    }
}
