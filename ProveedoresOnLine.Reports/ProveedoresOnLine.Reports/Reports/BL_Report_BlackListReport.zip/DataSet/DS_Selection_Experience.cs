﻿namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_Selection_Experience {
    }
}
namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_Selection_Experience {
    }
}
