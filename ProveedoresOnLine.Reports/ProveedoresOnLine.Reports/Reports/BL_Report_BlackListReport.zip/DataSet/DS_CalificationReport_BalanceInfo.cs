﻿namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_CalificationReport_BalanceInfo {
    }
}
namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_CalificationReport_BalanceInfo {
    }
}
