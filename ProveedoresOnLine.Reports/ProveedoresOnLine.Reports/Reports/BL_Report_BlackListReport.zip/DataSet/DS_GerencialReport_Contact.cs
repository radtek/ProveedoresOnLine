﻿namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_GerencialReport_Contact {
        partial class ContactInfoDataTable
        {
        }
    }
}
