﻿namespace ProveedoresOnLine.Reports.Reports.DataSet
{


    public partial class DS_GIBlackListreport
    {
    }
}
namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_GIBlackListreport {
    }
}
