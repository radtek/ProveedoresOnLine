﻿namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_CalificationReport_FinancialInfo {
        partial class DT_CalificationFinancialDataTable
        {
        }
    }
}
