﻿namespace ProveedoresOnLine.Reports.Reports.DataSet {
    
    
    public partial class DS_BlackListReport {
    }
}
